# Guide d'utilisation

## Lancement
- **Windows** : Double-cliquez sur `QuantumAI_Installer.exe` ou exécutez `install.bat`.
- **Linux/Mac** : `bash install.sh`

## Configuration
- Modifiez `config/config.ini` pour personnaliser le chemin et les options.
