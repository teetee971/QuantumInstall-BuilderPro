#!/bin/bash
echo "========================================="
echo "Quantum AI Pro - Installation Linux/Mac"
echo "========================================="

echo "Création du dossier..."
mkdir -p /opt/QuantumAIPro

echo "Copie des fichiers..."
cp -r * /opt/QuantumAIPro/

echo "Installation terminée."
